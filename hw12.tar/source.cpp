//Test Program Queue as Array 
 
#include <iostream>
#include "queue_array.h"
 
using namespace std;
   
int main()
{
    queueType<int> queue(100);
    int x, y;


    x = 4;
    y = 5;
    queue.enqueue(x);
    queue.enqueue(y);
    queue.front(x);
    int temp;
    queue.dequeue(temp);
    int z = x + 5;
    queue.enqueue(z);
    int a = 16;
    queue.enqueue(a);
    queue.enqueue(x);
    int b = y - 3;
    queue.enqueue(b);

    cout << "Queue Elements: ";

    while (!queue.isEmptyQueue())
    {
        int result;
        queue.front(result);
        cout << " " << result;
        queue.dequeue(result);
        	
    }

    cout << endl;

    cout << "------------------------------TEST2 double ------------------------------" << endl;
   
    queueType<double> queue_double;
    queue_double.initializeQueue();
    double dx, dy;

    dx = 3.1234;
    dy = 4.1234;
    queue_double.enqueue(dx);
    queue_double.enqueue(dy);
    queue_double.front(dx);
    double dtemp;
    queue_double.dequeue(dtemp);
    double da = dx + 5;
    queue_double.enqueue(da);
    double db = 16;
    queue_double.enqueue(db);
    queue_double.enqueue(dx);
    double dc = dy - 3;
    queue_double.enqueue(dc);

    cout << "Queue Elements: ";

    while (!queue_double.isEmptyQueue())
    {
        double dresult;
        if(queue_double.dequeue(dresult))
            cout << " " << dresult;	
        else
            cout << " error dequeueing";
    }

    cout << endl;


    cout << "------------------------------TEST3 STRING ------------------------------" << endl;
    
     queueType<string> queue_string;
     string sx, sy;
 
     queue_string.initializeQueue();
     sx = "hello";
     sy = "world";
     queue_string.enqueue(sx);
     queue_string.enqueue(sy);
     queue_string.front(sx);
     string stemp;
     queue_string.dequeue(stemp);
     string sa = sx + "5";
     queue_string.enqueue(sa);
     string sb = "16str";
     queue_string.enqueue(sb);
     queue_string.enqueue(sx);
     string sc = sy + "- 3";
     queue_string.enqueue(sc);
 
     cout << "Queue Elements: ";
 
     while (!queue_string.isEmptyQueue())
     {
        string sresult;
        if(queue_string.dequeue(sresult))
            cout << " " << sresult;	
        else
            cout << " error dequeueing";	
     }
 
     cout << endl;



    return 0;
}
