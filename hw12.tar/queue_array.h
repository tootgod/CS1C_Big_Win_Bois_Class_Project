#ifndef H_Queue_Array
#define H_Queue_Array

#include <iostream> 
#include <cassert>

#include "queueADT.h"

using namespace std;

template <class T>
class queueType: public queueADT<T>{
public:
    queueType(int queueSize = 100);
    queueType (const queueType&); //copy constructor 
    queueType<T>& operator =(const queueType<T>&); // assignment operator
    ~queueType(); // destructor
    bool isEmptyQueue() const ;
    
    bool isFullQueue() const ;
  
    void initializeQueue();
  
    bool front(T&result) const ;
  
    bool back(T&result) const ;
  
    bool enqueue(const T& queueElement);
     
    bool dequeue(T& result);
private:
    int maxSize ;
    int count;
    int queueFront;
    int queueRear;
    
    T* list;
};

//consturtor
template <class T>
queueType<T>::queueType(int queueSize ){
    if (queueSize <= 0){
        cout << "Queue size should be positive number " << endl;
    }
    else {
        maxSize = queueSize;
    }

    queueFront = -1;
    queueRear = -1;
    count = 0;
    list = new T[maxSize];
}

template <class T>
void queueType<T>::initializeQueue(){
    maxSize = 100;
    queueFront = -1;
    queueRear = -1;
    count = 0;
    list = new T[maxSize];
}

// copy constructor 
template <class T>
queueType<T>::queueType(const queueType<T>& objQueue){
  
    maxSize = objQueue.maxSize;
    queueFront = objQueue.queueFront;
    queueRear = objQueue.queueRear;
    count = objQueue.count;
    list = new T[objQueue.maxSize];
    std::copy(objQueue.list, objQueue.list+ objQueue.maxSize, list);

}

template <class T>
bool queueType<T>::isEmptyQueue() const{
    return (count == 0);
}

template <class T>
bool queueType<T>::isFullQueue() const {
    return (count == maxSize);
}

template <class T>
bool queueType<T>::enqueue(const T& newElement){
    if (!isFullQueue()){
        queueRear = (queueRear + 1 ) % maxSize;
        count ++ ;
        list[queueRear] = newElement;
        if(count == 1){
            queueFront = queueRear;
        }
        return true;
    }
    else{
        cout << "queue is full now" << endl;
        return false;
    }
    
}

template <class T>
bool queueType<T>::front(T& result) const{
    if(isEmptyQueue())
        return false;

    result= list[queueFront]; 
    return true;
}

template <class T>
bool queueType<T>::back(T& result) const{
    if(isEmptyQueue())
        return false;
    
    result= list[queueRear];
    return true;
} 

template <class T>
bool queueType<T>::dequeue(T&result){

    if(!isEmptyQueue()){
        count --;
        int oldFront = queueFront;
        queueFront = (queueFront + 1 ) % maxSize;
        result= list[oldFront];
        if(count == 0){
            queueFront = -1;
            queueRear  = -1;
        }
        return true;
    }else{
        return false;
    }
}

template <class T>
queueType<T>::~queueType(){
    if(list)
        delete [] list;
}

template <class T>
queueType<T>& queueType<T>::operator =(const queueType<T>& rhs){
    if(this != &rhs){
        queueType copy(rhs); // Invoke copy constructor
        std::swap(copy.maxSize, maxSize);
        std::swap(copy.count, count);
        std::swap(copy.queueFront, queueFront);
        std::swap(copy.queueRear, queueRear);
        std::swap(copy.list, list);
    }
    return *this;
}
#endif