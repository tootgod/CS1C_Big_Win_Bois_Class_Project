#ifndef H_queueADT
#define H_queueADT

template<class T>
class queueADT{
public:
    virtual bool isEmptyQueue() const = 0;
  
    virtual bool isFullQueue() const = 0;

    virtual void initializeQueue() = 0;

    virtual bool front(T&result) const = 0;

    virtual bool back(T&result) const = 0;

    virtual bool enqueue(const T& queueElement) = 0;
   
    virtual bool dequeue(T& result) = 0;

};


#endif